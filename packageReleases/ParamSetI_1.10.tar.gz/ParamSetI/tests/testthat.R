library(testthat)
library(ParamSetI)

test_check("ParamSetI")
