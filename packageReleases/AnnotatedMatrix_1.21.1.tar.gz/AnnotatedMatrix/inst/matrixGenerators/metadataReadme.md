### Template file

This is a template file that is copied into the `byAuthority/./metadata`
directories. This text (above the horizontal rule) will not be copied.

----
# AnnotatedMatrix Files - Metadata files

These files are primarily support files used during the creation of
the MatrixMarket files in the parent directory,
[byAuthority](../). The files may be of direct utility if 'connection'
information is not needed. Most or all should be TSV format with
header rows.

The nomenclature follows the same format as 

