### Template file

This is a template file that is copied into the first subdirectories
of the `byNamespace` directories. This text (above the horizontal
rule) will not be copied.

----
# Namespace <NS1>

This folder holds matrix files that have the `<NS1>` namespace
assigned to _either_ their row _or_ column dimensions. The files
themselves will be in one of the subfolders, which indicate the other
namespace.
