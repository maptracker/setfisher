library(testthat)
library(AnnotatedMatrix)

test_check("AnnotatedMatrix")
