library(testthat)
library(EventLogger)

test_check("EventLogger")
